﻿namespace StringCalculatorKata.Contracts
{
    public interface ILogger
    {
        void Write(string message);
    }
}
