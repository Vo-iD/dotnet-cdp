﻿namespace StringCalculatorKata.Contracts
{
    public interface IWebService
    {
        void Notify(string message);
    }
}
